goog.provide("shadow.js.shim.module$$web3modal$wagmi");
goog.provide("module$shadow_js_shim_module$$web3modal$wagmi");
shadow.js.shim.module$$web3modal$wagmi = shadow$bridge("@web3modal/wagmi");
module$shadow_js_shim_module$$web3modal$wagmi.default = shadow.js.shim.module$$web3modal$wagmi;

//# sourceMappingURL=shadow.js.shim.module$$web3modal$wagmi.js.map
