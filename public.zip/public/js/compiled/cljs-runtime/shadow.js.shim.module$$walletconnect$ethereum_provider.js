goog.provide("shadow.js.shim.module$$walletconnect$ethereum_provider");
goog.provide("module$shadow_js_shim_module$$walletconnect$ethereum_provider");
shadow.js.shim.module$$walletconnect$ethereum_provider = shadow$bridge("@walletconnect/ethereum-provider");
module$shadow_js_shim_module$$walletconnect$ethereum_provider.default = shadow.js.shim.module$$walletconnect$ethereum_provider;

//# sourceMappingURL=shadow.js.shim.module$$walletconnect$ethereum_provider.js.map
