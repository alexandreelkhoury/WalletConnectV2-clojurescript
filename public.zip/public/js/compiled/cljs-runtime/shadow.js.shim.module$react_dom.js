goog.provide("shadow.js.shim.module$react_dom");
goog.provide("module$shadow_js_shim_module$react_dom");
shadow.js.shim.module$react_dom = shadow$bridge("react-dom");
module$shadow_js_shim_module$react_dom.default = shadow.js.shim.module$react_dom;

//# sourceMappingURL=shadow.js.shim.module$react_dom.js.map
