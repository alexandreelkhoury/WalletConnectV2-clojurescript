goog.provide("shadow.js.shim.module$react");
goog.provide("module$shadow_js_shim_module$react");
shadow.js.shim.module$react = shadow$bridge("react");
module$shadow_js_shim_module$react.default = shadow.js.shim.module$react;

//# sourceMappingURL=shadow.js.shim.module$react.js.map
