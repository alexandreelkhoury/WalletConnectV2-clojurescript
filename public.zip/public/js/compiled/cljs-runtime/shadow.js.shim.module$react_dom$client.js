goog.provide("shadow.js.shim.module$react_dom$client");
goog.provide("module$shadow_js_shim_module$react_dom$client");
shadow.js.shim.module$react_dom$client = shadow$bridge("react-dom/client");
module$shadow_js_shim_module$react_dom$client.default = shadow.js.shim.module$react_dom$client;

//# sourceMappingURL=shadow.js.shim.module$react_dom$client.js.map
