goog.provide("shadow.js.shim.module$wagmi$react");
goog.provide("module$shadow_js_shim_module$wagmi$react");
shadow.js.shim.module$wagmi$react = shadow$bridge("wagmi/react");
module$shadow_js_shim_module$wagmi$react.default = shadow.js.shim.module$wagmi$react;

//# sourceMappingURL=shadow.js.shim.module$wagmi$react.js.map
