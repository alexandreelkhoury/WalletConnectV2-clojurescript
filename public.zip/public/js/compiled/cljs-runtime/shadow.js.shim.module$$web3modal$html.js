goog.provide("shadow.js.shim.module$$web3modal$html");
goog.provide("module$shadow_js_shim_module$$web3modal$html");
shadow.js.shim.module$$web3modal$html = shadow$bridge("@web3modal/html");
module$shadow_js_shim_module$$web3modal$html.default = shadow.js.shim.module$$web3modal$html;

//# sourceMappingURL=shadow.js.shim.module$$web3modal$html.js.map
